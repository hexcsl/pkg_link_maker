path_usb_test_bin="/dev_usb000/category_game.xml";
path_hdd_test_bin="/dev_blind/vsh/resource/explore/xmb/category_game.xml";
file_size=37449;